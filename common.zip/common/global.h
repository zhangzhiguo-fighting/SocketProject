#ifdef _GLOBAL_H
#define _GLOBAL_H
extern char conf_ans[50];
#endif
