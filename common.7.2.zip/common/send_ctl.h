
#ifndef _SEND_CTL_H
#define _SEND_CTL_H
void send_ctl();
#endif
