#ifndef _SHOW_DATA_STREAM_H
#define _SHOW_DATA_STREAM_H
char data_stream[20];
void show_data_stream(int type);
#endif
